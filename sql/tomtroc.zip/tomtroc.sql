-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : jeu. 08 jan. 2026 à 16:31
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `tomtroc`
--

-- --------------------------------------------------------

--
-- Structure de la table `books`
--

CREATE TABLE `books` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `status` enum('available','unavailable') NOT NULL DEFAULT 'available',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `books`
--

INSERT INTO `books` (`id`, `user_id`, `title`, `author`, `description`, `image_path`, `status`, `created_at`, `updated_at`) VALUES
(6, 5, 'Esther', 'Alabaster', 'L’intrigue est celle du Livre d’Esther dans la Bible, que l’édition Alabaster reprend avec une direction artistique contemporaine. Elle se déroule à la cour du roi perse Assuérus, où Esther, une jeune femme juive devenue reine, cache ses origines sur les conseils de son cousin Mardochée.​\n\nQuand le vizir Haman obtient un décret royal ordonnant l’extermination des Juifs de l’empire, Mardochée pousse Esther à risquer sa vie en intervenant auprès du roi. Par son courage et sa ruse (banquets, dévoilement de complot), elle fait tomber Haman, renverse la situation et obtient la délivrance de son peuple, événement qui donnera naissance à la fête de Pourim.​', 'uploads/books/book_6946638dbf5002.58120497.webp', 'available', '2025-12-13 22:46:46', '2025-12-31 19:26:55'),
(7, 6, 'The Kinfolk Table', 'Nathan Williams', 'J\'ai récemment plongé dans les pages de \'The Kinfolk Table\' et j\'ai été enchanté par cette œuvre captivante. Ce livre va bien au-delà d\'une simple collection de recettes ; il célèbre l\'art de partager des moments authentiques autour de la table. Les photographies magnifiques et le ton chaleureux captivent dès le départ, transportant le lecteur dans un voyage à travers des recettes et des histoires qui mettent en avant la beauté de la simplicité et de la convivialité. Chaque page est une invitation à ralentir, à savourer et à créer des souvenirs durables avec les êtres chers. \'The Kinfolk Table\' incarne parfaitement l\'esprit de la cuisine et de la camaraderie, et il est certain que ce livre trouvera une place spéciale dans le cœur de tout amoureux de la cuisine et des rencontres inspirantes.', 'uploads/books/book_694663fbb3ad90.07033201.webp', 'available', '2025-12-13 22:51:03', '2026-01-02 12:22:57'),
(8, 6, 'Wabi Sabi', 'Beth Kempton', 'C’est un livre de développement personnel qui présente la philosophie japonaise du wabi sabi comme art de voir la beauté dans l’imperfection, la simplicité et l’impermanence. L’autrice l’utilise comme antidote à la quête de perfection et à l’hyper-performance, en montrant comment ralentir, accepter les limites et trouver du sens dans une vie ordinaire. L’ouvrage mêle explications culturelles, pistes de réflexion et conseils pratiques pour intégrer cette approche dans le quotidien (maison, travail, relations, rapport au temps). Il vise des lecteurs qui veulent un mode de vie plus sobre, attentif et aligné, sans tomber dans le manuel de productivité classique.', 'uploads/books/book_694663d56f69b5.62254867.webp', 'available', '2025-12-13 22:52:53', '2026-01-01 14:34:25'),
(9, 7, 'Milk & honey', 'Rupi Kaur', 'Ce recueil de poésie contemporaine explore, avec une langue très épurée, les fractures intimes et la reconstruction de soi. Il aborde sans détour les thèmes des violences, de l’amour, de la perte et de la guérison émotionnelle, dans une forme accessible qui parle autant aux lecteurs occasionnels qu’aux amateurs de poésie.​\n\nAu fil de courts poèmes en vers libres, l’autrice trace un parcours qui va de la douleur à l’acceptation, puis à l’affirmation de soi, en mêlant vulnérabilité et puissance. C’est un livre pensé pour être offert ou s’offrir, qui trouve naturellement sa place dans une boutique orientée bien‑être, développement personnel ou littérature engagée.​', 'uploads/books/book_6946647931e992.24763907.webp', 'available', '2025-12-13 22:59:44', '2025-12-31 19:27:03'),
(10, 8, 'Delight!', 'Justin Rossow', 'C’est un livre de spiritualité chrétienne centré sur l’idée que le discipulat est avant tout une histoire de joie partagée entre Dieu et l’être humain. Justin Rossow y présente la vie de foi non comme un ensemble de devoirs pesants, mais comme une aventure relationnelle marquée par le plaisir d’aimer et d’être aimé.​\n\nL’ouvrage explore différentes facettes de cette “delight” (joie réfléchie, ludique, gustative, désirante, etc.) et montre comment ces expériences concrètes peuvent transformer la manière de suivre Jésus au quotidien. Il s’adresse surtout à des lecteurs chrétiens qui veulent redécouvrir le discipulat sous un angle plus vivant, incarné et joyeux, sans renier la dimension de repentance mais en la replaçant aux côtés de la joie comme don de l’Esprit.​', 'uploads/books/book_694664bbe70968.73729348.webp', 'unavailable', '2025-12-13 23:05:11', '2025-12-31 19:27:04'),
(11, 9, 'Milwaukee Mission', 'Elder Cooper Low', 'Milwaukee Mission d\'Elder Cooper Low, c\'est l\'histoire hilarante d\'un jeune missionnaire mormon largué dans les rues de Milwaukee, Wisconsin, avec son compère en costard-cravate trop serré.\n\nÉpopée porte-à-porte\nImagine deux jeunots LDS qui sonnent chez les brasseurs de bière : \"Bonjour, on a le Livre de Mormon, pas la Budweiser !\" Refus en rafale, chiens qui mordent les chevilles, et une mémé qui les prend pour des vendeurs de vide-greniers. Cooper Low raconte les galères avec un humour auto-dérisoire : tempêtes de neige, pizzas gratuites volées (oups, \"partagées\"), et conversions improbables genre biker repenti.​\n\nLeçons en mode comédie\nEntre prières sous la pluie et débats théologiques avec des hecklers, c\'est un road trip spirituel foireux qui finit en growth personnel. Victoires minuscules (un thé avec un curieux), défaites épiques (un slam de porte mythique), le tout saupoudré de foi blindée. Lecture feel-good pour rigoler des missions ratées.', 'uploads/books/book_694664e9ecfbe5.28895758.webp', 'available', '2025-12-13 23:11:49', '2025-12-31 19:27:08'),
(12, 10, 'Minimalist Graphics', 'Julia Schonlau', 'Minimalist Graphics de Julia Schonlau est un recueil visuel de 2011 qui compile des exemples de design graphique épuré, avec logos, affiches et identités visuelles réduites à l\'essentiel. Fort en inspiration pour les pros en quête de clarté, il pèche par son manque de profondeur théorique – pas d\'analyse technique sur les ratios dorés ou les grilles modulaire, juste du \"regardez comme c\'est clean\".​\n\nPoints forts\nExemples percutants : 200+ cas réels de studios (typiquement européens/américains) qui prouvent l\'efficacité du minimalisme en print et digital, avec une mise en page aérée qui respire la qualité.\n\nAccessibilité pro : Idéal pour brainstorm rapide, palettes limitées (1-3 couleurs) et formes géométriques qui boostent la maintenabilité des assets SVG/CSS.​\n\nCritiques constructives\nManque de process : Aucune déconstruction des workflows (outils comme Illustrator/Sketch, contraintes responsive) ; suggestion : ajouter des case studies avec wireframes avant/après.\n\nDaté sans timeless : 2011 sent le flat design pré-iOS7, ignore les évolutions web (dark mode, accessibilité WCAG) ; mise à jour 2025 avec perf metrics (Lighthouse scores) serait top.\n\nPrix/valeur : À ~30€, c\'est cher pour un coffee table book sans exercices pratiques ; optez pour le PDF si dispo, ou complétez avec \"Thinking with Type\" pour du technique solide.\n\nGlobalement, 7/10 : bon kickstart visuel, mais insuffisant seul pour un dev fullstack comme toi qui priorise sécurité/maintenabilité – pair avec des refs code comme CSS-Tricks pour scaler en prod. Prochain ?​', 'uploads/books/book_6946651a3eaa15.03342688.webp', 'available', '2025-12-13 23:15:33', '2025-12-31 19:27:10'),
(13, 7, 'Hygge', 'Meik Wiking', 'Hygge de Meik Wiking (2016) est un manifeste convivial sur l\'art danois du hygge, ce cosy bien-être quotidien qui fait la réputation des Danois comme les plus heureux du monde. L\'auteur, boss de l\'Happiness Research Institute, distille recettes et rituels pour infuser chaleur humaine dans un monde speed – sans jargon psy lourd.\n\nPoints forts\nPratique et actionable : Astuces concrètes genre bougies low-cost, plaids familiaux, cafés slow avec potins sans écrans ; booste la productivité indirecte via bien-être mental, top pour devs en burnout.\n\nData-backed hygge : Chiffres sur pourquoi hygge > luxe (ex. : thé > champagne pour le bonheur mesuré), avec photos cosy qui vendent du rêve nordique accessible partout, même à Provins.\n\nCritiques constructives\nSuperficiel culturel : Glose sur hygge sans creuser origines linguistiques ou variantes nordiques ; suggestion : annexe comparative hygge vs. fika suédois avec benchmarks scientifiques (études WHO sur bonheur).\n\nManque tech/modernes : Ignore hygge digital (dark mode apps, notifications off) ou remote work ; update 2025 avec protocoles Docker pour \"home office hygge\" (low-light setups sécurisés) serait pertinent pour fullstack.', 'uploads/books/book_69466469e09325.45146346.webp', 'available', '2025-12-13 23:18:50', '2025-12-31 19:27:13'),
(14, 11, 'Innovation', 'Matt Ridley', 'Innovation (How Innovation Works) de Matt Ridley (2020) démystifie l\'innovation comme un processus darwinien décentralisé : pas de génies solitaires, mais échanges libres, sérendipité et itérations cumulatives qui transforment idées en tech viable. Ridley, biologiste libéral, plaque une grille évolutionniste sur histoire économique – top pour décortiquer pourquoi liberté > planification étatique en R&D.​\n\nPoints forts\nCadre théorique robuste : Exemples concrets (vaccins, internet, moteurs) montrent innovation comme \"échange d\'idées\" bottom-up ; aligné maintenabilité via open collab (Git-like avant Git), avec data sur brevets freinant plus qu\'ils boostent.\n\nAnti-mythes pragmatique : Déconstruit \"eureka\" isolé (Edison dispensable, multiples inventeurs simultanés) ; idéal pour fullstack : priorise perf via concurrence, pas subventions risquées.​\n\nCritiques constructives\nBiais idéologique : Trop anti-État (ignore succès DARPA/GPS) ; suggestion : benchmarks quantitatifs (ROI brevets vs. open source, metrics GitHub forks) pour valider libre-marché en prod réelle.\n\nFaible tech moderne : 2020 pré-IA/LLM ; manque protocoles sécurisés (zero-trust en innovation distribuée) ou Docker pour scale collab ; update 2025 avec cas blockchain/AGI serait critique.', 'uploads/books/book_69466542d51a53.10833464.webp', 'available', '2025-12-13 23:21:06', '2025-12-31 19:27:17'),
(15, 12, 'Psalms', 'Alabaster', 'Psalms de Alabaster (2017-2021, NLT/ESV/KJV) est une édition visuelle du Livre des Psaumes : 232 pages de poèmes bibliques crus sur deuil, joie et quête divine, boostés par 75% d\'images photo customisées pour un rendu magazine-like. Conçu pour millennials visuels, layout aéré (colonnes variées, typos discrètes, papier mat 80#) rend la lecture immersive sans intimider.​\n\nPoints forts\nDesign pro accessible : Photos thought-provoking (littérales/figuratives) facilitent mémorisation passages ; format 7.5x9.5\" portable, binding perfect pour usage quotidien – top maintenabilité vs Bibles traditionnelles fragiles.\n\nEngagement moderne : Thèmes humains (lament, pardon) avec visuels frais ; idéal anti-burnout dev, comme un \"dark mode spirituel\" pour focus long.​', 'uploads/books/book_6946656ea4c0e7.88731523.webp', 'available', '2025-12-13 23:23:33', '2025-12-31 19:27:19'),
(16, 13, 'Thinking, Fast & Slow', 'Daniel Kahneman', 'Thinking, Fast and Slow de Daniel Kahneman (2011) décortique les deux modes de pensée humaine : Système 1 (rapide, intuitif, biaisé) vs Système 2 (lent, analytique, effortful). Nobel d\'éco 2002, Kahneman plaque behavioral economics sur cognition, avec expériences labo prouvant comment heuristics foireuses (anchoring, availability) plombent décisions rationnelles – cadre essentiel pour debugger biases en dev/prod.', 'uploads/books/book_694666ce8c8fe9.28872118.webp', 'unavailable', '2025-12-13 23:35:22', '2025-12-26 11:00:58'),
(17, 14, 'A Book Full Of Hope', 'Rupi Kaur', 'A Book Full of Hope de Rupi Kaur (2024) est un recueil de poésie illustrée où Kaur distille espoir resilient face à trauma, amour et guérison, avec son style minimaliste en lowercase, slashes et doodles épurés. Suite spirituelle à ses hits (Milk & Honey), ça cible millennials en quête d\'empowerment soft – vibes Instagram-ready pour catharsis rapide.​', 'uploads/books/book_694665be9cf234.58675307.webp', 'available', '2025-12-13 23:45:23', '2025-12-20 10:00:46'),
(18, 15, 'The Subtle Art of Not Giving a F*ck', 'Mark Manson', 'The Subtle Art of Not Giving a F*ck de Mark Manson (2016) est un anti-selfhelp cru qui prône choisir ses \"f*cks\" à donner : focus sur valeurs solides (responsabilité, limites) vs bullshit culturel (succès facile, positivity toxique). Manson, ex-blogger, balance anecdotes perso et philo stoïcienne pour hacker mindset – appliqué à dev : priorise sécurité (boundaries anti-burnout) sur perf illusoire.​', 'uploads/books/book_694665e7f1e538.03235906.webp', 'available', '2025-12-13 23:48:00', '2026-01-06 20:53:41'),
(19, 16, 'Narnia', 'C.S Lewis', 'Narnia de C.S. Lewis (La Chronique de Narnia, 1950-1956, 7 tomes) est une saga fantasy chrétienne où enfants anglais (Pevensie & co) franchissent portails magiques vers Narnia : monde enchanté avec Aslan (lion christique), sorcières, faunes et batailles épiques pour restaurer ordre divin. Lewis, oxfordien athée converti, encode apologétique sous allégories (rédemption, sacrifice) – appliqué dev : leçons sur architectures résilientes (royaumes rebuild post-corruption).', 'uploads/books/book_6946661ad24a06.83202936.webp', 'unavailable', '2025-12-13 23:49:36', '2025-12-26 10:59:24'),
(20, 17, 'Company Of One', 'Paul Jarvis', 'Company of One de Paul Jarvis (2018, trad. One en FR) défie le dogme \"grow or die\" : une \"company of one\" reste petite par choix pour maximiser autonomie, rentabilité et agilité, via systèmes scalables (automatisation, pricing stratégique, rétention clients). Ex-freelance (Fathom Analytics bootstrappé), Jarvis prône simplicité > complexité bureaucratique – aligné fullstack : priorise sécurité (contrôle total) et maintenabilité (MVP itératif) sur perf scale infinie.​', 'uploads/books/book_694666523376f7.10221089.webp', 'available', '2025-12-13 23:51:38', '2025-12-20 10:03:14'),
(21, 18, 'The Two Towers', 'J.R.R Tolkien', 'The Two Towers de J.R.R. Tolkien (1954, tome 2 du Seigneur des Anneaux) divise la quête anti-Anneau en arcs parallèles : Frodo/Sam vers Mordor (stewardship résiliente vs corruption), Aragorn/Gandalf à Helm\'s Deep (défense scalable), et Ents éco-ingénierie. Tolkien, philologue oxfordien, forge un worldbuilding linguistique immuable – appliqué fullstack : architectures décentralisées (Fellowship comme microservices) priorisant sécurité (One Ring isolation) sur perf centralisée.', 'uploads/books/book_6946642db7ac67.87836152.webp', 'available', '2025-12-13 23:54:03', '2025-12-26 11:13:15');

-- --------------------------------------------------------

--
-- Structure de la table `messages`
--

CREATE TABLE `messages` (
  `id` int(10) UNSIGNED NOT NULL,
  `sender_id` int(10) UNSIGNED NOT NULL,
  `receiver_id` int(10) UNSIGNED NOT NULL,
  `content` text NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `read_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `pseudo` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `avatar_path` varchar(255) DEFAULT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`id`, `pseudo`, `email`, `avatar_path`, `password_hash`, `created_at`, `updated_at`) VALUES
(5, 'CamilleClubLit', 'camille.clublit@tomtroc.test', 'avatar_69544f8dda80e4.11264477.webp', '$2y$10$b15AR5iDRK7LwnvBQOoXt.GPUU0smz.p.eDK/Jf.UVr.nrZiEcGB.', '2025-12-13 22:08:02', '2025-12-30 23:17:49'),
(6, 'Alexlecture', 'alexlecture@tomtroc.test', 'avatar_69433e43c731c7.25291244.webp', '$2y$10$q9k9RdMdGYxDP6VL4vfjXuReIW8SPBwCBm6AXmHSWxhRihQurH7HS', '2020-10-15 12:09:11', '2026-01-05 15:32:41'),
(7, 'Hugo1990_12', 'hugo1990_12@tomtroc.test', NULL, '$2y$10$iWexzQkmL1IVEX9Y/NSbUeOUXCHW1YHX.IZZB.xWGqNMDaIQ90c5.', '2025-12-13 22:10:30', '2025-12-20 09:44:51'),
(8, 'Juju1432', 'juju1432@tomtroc.test', NULL, '$2y$10$oQ.Em7TsB1byxYIN4yA6/eVtoRRdJOpxX.H0EPgPm4ewgNpaSyPQO', '2025-12-13 22:11:08', '2025-12-18 00:39:19'),
(9, 'Christiane75014', 'christiane75014@tomtroc.test', 'avatar_6946626b0f1076.19203718.webp', '$2y$10$Cyeo.R7Jk0OkO3VHiDsQ5uMsw3YbIGs1jvWP4.gYnnraDZ4GbbXPq', '2025-12-13 22:11:36', '2025-12-20 09:46:35'),
(10, 'Hamzalecture', 'hamzalecture@tomtroc.test', NULL, '$2y$10$QtGz64bq9ntFsVg8GQxRruGmZn0FDGl/u9NkLvTO8xwjl0v5ct08C', '2025-12-13 22:12:25', '2025-12-18 00:41:28'),
(11, 'Lou&Ben50', 'lou.ben50@tomtroc.test', NULL, '$2y$10$yUUlIaU5B.bR0IwMIqWlpOCrNp8SW8nTT51QnDWOrt5hVi7GJC3US', '2025-12-13 22:13:06', '2025-12-18 00:42:31'),
(12, 'Lolobzh', 'lolobzh@tomtroc.test', NULL, '$2y$10$/U2Gxdikk1RB4V2pOLcvfecu30Jv4rfXFzWqyWDdJrRQgXUZ9Vzti', '2025-12-13 22:13:30', '2025-12-18 00:44:09'),
(13, 'Sas634', 'sas634@tomtroc.test', NULL, '$2y$10$5nWHbhQVju3rREj1fL6jhuHXM2x/EC0e4j4hm03gfM9k9GL0gZPr2', '2025-12-13 22:14:02', '2025-12-18 00:44:41'),
(14, 'ML95', 'ml95@tomtroc.test', NULL, '$2y$10$esrdPepmKC/ZqEWdrDXUv.UeE5LstHhLzLY6xMu3TjBEG5K3GUyG6', '2025-12-13 22:14:34', '2025-12-18 00:45:18'),
(15, 'Verogo33', 'verogo33@tomtroc.test', NULL, '$2y$10$77wG1SdwN3qEPG1PHoAfKemthvDcXXylOQ6cQECxdqVELeZxh4ugC', '2025-12-13 22:15:17', '2025-12-18 00:46:01'),
(16, 'AnnikaBrahms', 'annika.brahms@tomtroc.test', NULL, '$2y$10$Ql9nla1fzvQND.tu8i.I4OdxF086nY4zwZvrwo7Yv4L..VdU14aRy', '2025-12-13 22:15:46', '2025-12-18 00:46:38'),
(17, 'Victoirefabr912', 'victoirefabr912@tomtroc.test', NULL, '$2y$10$YyHga6zQBSWuXfPS8tWUHui/LZubukQYnCKTi0hswCHCUBuMBSMhu', '2025-12-13 22:16:42', '2025-12-18 00:47:04'),
(18, 'Lotrfanclub67', 'lotrfanclub67@tomtroc.test', 'avatar_69433e7ad4b4d9.79966719.webp', '$2y$10$88ww6mDSKTnC1DuIyMdX/envBEMPfs5A6NAlZciyYCjVSlFLx6Icu', '2025-12-13 22:17:09', '2025-12-18 00:36:36');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_books_user` (`user_id`),
  ADD KEY `idx_books_status` (`status`),
  ADD KEY `idx_books_title` (`title`);

--
-- Index pour la table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_messages_receiver_created` (`receiver_id`,`created_at`),
  ADD KEY `idx_messages_pair` (`sender_id`,`receiver_id`,`created_at`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_users_email` (`email`),
  ADD UNIQUE KEY `uq_users_pseudo` (`pseudo`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT pour la table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=72;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `books`
--
ALTER TABLE `books`
  ADD CONSTRAINT `fk_books_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `messages`
--
ALTER TABLE `messages`
  ADD CONSTRAINT `fk_messages_receiver` FOREIGN KEY (`receiver_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk_messages_sender` FOREIGN KEY (`sender_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
